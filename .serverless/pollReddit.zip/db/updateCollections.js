const updateSubCollections = require('./updateSubCollections');

updateSubCollections();
